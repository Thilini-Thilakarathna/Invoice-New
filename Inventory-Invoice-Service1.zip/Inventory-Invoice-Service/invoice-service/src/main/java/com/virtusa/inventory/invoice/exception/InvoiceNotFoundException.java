package com.virtusa.inventory.invoice.exception;

public class InvoiceNotFoundException extends RuntimeException {
}
