import java.util.ArrayList;
import java.util.List;

public class Employee {
String name;
Integer marks;


public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getMarks() {
	return marks;
}
public void setMarks(Integer marks) {
	this.marks = marks;
}



public Employee(String name, Integer marks) {
	
	this.name = name;
	this.marks = marks;
}
public Employee(String name) {
	
	this.name = name;
}

public static List<Employee> getAllEmployee(){
	List<Employee> employee= new ArrayList<>();
	employee.add(new Employee("Thilini", 98));
	employee.add(new Employee("Nishi", 58));
	employee.add(new Employee("Krish", 95));
	employee.add(new Employee("Suranga", 90));
	employee.add(new Employee("Amal", 88));
	employee.add(new Employee("Erandi", 78));
	
	return employee;
}
public Employee(Integer marks) {

	this.marks = marks;
}

@Override
	public String toString() {
			return name +": "+ marks;
	}
}
