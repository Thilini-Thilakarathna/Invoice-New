import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Student {

	String name;
	String dob;
	
	
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Student(String name, String dob) {
		
		this.name = name;
		this.dob = dob;
	}
	
	
	public static List<Student> getAll() {
		List<Student> student= new ArrayList<Student>();
		student.add(new Student("Thilini", "1994-05-14"));
		student.add(new Student("Thilini1", "2012-05-14"));
		
		return student;
	}
	
	
}
