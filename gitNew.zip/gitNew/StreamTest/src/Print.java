

@FunctionalInterface
public interface Print {

	public void print(String text);
	
	Print p =(s)-> {
		System.out.println(s.toUpperCase());
		
	};
	
	
}
