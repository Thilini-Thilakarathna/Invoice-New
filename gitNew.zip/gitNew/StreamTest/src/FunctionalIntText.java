
public class FunctionalIntText {

	
	public static void main(String[] args) {
		printHtml();
	}
	
	
	public static void printHtml() {
	
		Print p;
	}

	
	
	}
