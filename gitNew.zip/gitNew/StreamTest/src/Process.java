import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class Process {
public static void main(String[] args) {
	
	List<Employee> employee1= Employee.getAllEmployee().stream().map(e-> new Employee("Eng: "+e.getName(), e.getMarks()*2))
			.collect(Collectors.toList());
	
	
	System.out.println(employee1.toString());
	
	List<Employee> employees= Employee.getAllEmployee().stream().filter(e->e.getName().contains("i"))
			.map(e-> new Employee(e.getName(), e.getMarks()*3)).collect(Collectors.toList());
			
			
			
		//	Employee.getAllEmployee().stream().map(e -> new Employee(e.filter(e.getName().contains("i")),e.getMarks()*3)).collect(Collectors.toList());
			
		System.out.println(employees.toString());
		
		List<Student> student= Student.getAll().stream().filter(e-> (new LocalDate(new DateTimeFormatter(e.getDob())).getYear()>18)).collect(Collectors.toList());
		
}
}
