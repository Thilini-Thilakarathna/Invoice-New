import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class F7ForEach {
	
	public static void main(String[] args) {
	//Employee.getAllEmployee().stream().sorted((e1,e2)->new Integer(e1.getName().length()).compareTo(e2.getName().length()>5)).collect(Collectors.toList());
	
	
	//Employee.getAllEmployee().stream().filter(e->e
		
		
		Employee.getAllEmployee().stream().filter(e->e.getName().length()>=5)
		.map(e-> new Employee(e.getName().toUpperCase(),e.getMarks()))
		.sorted(Comparator.comparing(Employee::getName).reversed()).forEach(System.out::println);
		
		
		
	}

}
