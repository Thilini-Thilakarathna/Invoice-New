import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class F10MapSort {
public static void main(String[] args) {
	Map<String, Integer> students= new HashMap<>();
	students.put("Krish", 56);
	students.put("Nuwan", 36);
	students.put("Bagya", 78);
	students.put("Hasini", 96);
	students.put("Suranga", 76);
	students.put("Erandi", 66);
	
students.entrySet().stream().filter(e-> e.getValue() >=60)
			
		.sorted((e1,e2)->e1.getValue().compareTo(e2.getValue())).collect(Collectors.toList()).stream().forEach(e-> System.out.println(e.getKey()));

	//sorted((e1,e2)->e1.getMarks().compareTo(e2.getMarks())).collect(Collectors.toList());


List<String> strings= new ArrayList<String>();
students.entrySet().stream().filter(e-> e.getValue()>=60).sorted((s1,s2)-> -s1.getValue().compareTo(s2.getValue()))
.peek(s-> strings.add(s.getKey())).collect(Collectors.toList());

System.out.println(strings);



		Map<Integer,String> vehicles= new HashMap<>();
		vehicles.put(10, "Car");
		vehicles.put(20, "SUV");
		vehicles.put(50, "Jeep");
		vehicles.put(12, "Ship");
		vehicles.put(15, "Bus");
		vehicles.put(16, "Lorry");
		vehicles.put(4, "Cycle");
		
		List<Integer> intergers= new ArrayList<>();
		vehicles.entrySet().stream().sorted((v1,v2)-> -v1.getKey()
				.compareTo(v2.getKey())).peek(v-> intergers.add(v.getKey())).collect(Collectors.toList());
		
		System.out.println(intergers);
		
		List<String> strings1= new ArrayList<>();
		vehicles.entrySet().stream().filter(v-> !v.getValue().contains("Ship")).sorted((v1,v2)-> v1.getValue()
				.compareTo(v2.getValue())).peek(v-> strings1.add(v.getValue())).collect(Collectors.toList());
		
		
		
		
		System.out.println(strings1);
		
		
		
		
	//	System.out.println(vehicles.get(strings1));
		

}
}
