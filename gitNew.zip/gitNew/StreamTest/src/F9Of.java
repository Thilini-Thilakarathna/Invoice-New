import java.util.stream.Stream;

public class F9Of {
public static void main(String[] args) {
	Stream.of(1,8,5,6,4,7,9).sorted().forEach(System.out::println);
	
	Integer[] integers= {4,8,5,6,7,1,7,2,4,6};
	Stream<Integer> integerStream= Stream.of(integers).sorted().forEach(System.out::println);


}
}
