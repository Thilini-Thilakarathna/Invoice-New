
public class F8Array {
public static void main(String[] args) {
	Employee [] employee= Employee.getAllEmployee().stream().toArray(Employee[]::new);
	
	
}
}
